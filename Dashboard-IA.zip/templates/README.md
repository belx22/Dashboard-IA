# Medical UI Kit
MEDIKIT is an HTML UI KIT created for medical companies that want to build a medical app. The template includes the Landing page and the Administration Dashboard designs. The layout is built using an original design concept, some amazing features, customizable elements and a perfect responsive code.
